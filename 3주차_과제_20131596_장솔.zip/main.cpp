#include <stdio.h>
#include <string.h>
#include <iostream>

using namespace std;
class Str
{
	private :
		char *str; // string의 내용.
		int len; // string의 길이.
	public :
		Str(const char *neyong); // neyong은 초기화할 내용이 들어감.
		~Str(); // 소멸자.
		int length(void); // string의 길이를 리턴하는 함수.
		char *contents(void); // string의 내용을 리턴하는 함수.
		int compare(class Str &a); // a의 내용과 strcmp.
		int compare(const char *a); // a의 내용과 strcmp.
		void operator=(const char *a); // string의 값을 대입.
		void operator=(class Str &a); // Str의 내용을 대입.
};
Str::Str(const char *neyong) {
	this->len = strlen(neyong);
	this->str = new char[this->len+1];
	strcpy(this->str,neyong);
}
Str::~Str() {
	delete[] this->str;
}
int Str::length(void) {
	return strlen(this->str);
}
char* Str::contents(void) {
	return this->str;
}
int Str::compare(class Str &a) {
	return strcmp(this->str,a.str);
}
int Str::compare(const char *a ) {
	return strcmp(this->str,a);
}
void Str::operator=(const char *a) {
	delete[] this->str;
	len = strlen(a);
	this->str = new char[len+1];
	strcpy(this->str,a);
}
void Str::operator=(class Str &a) {
	delete[] this->str;

	len = strlen(a.str);
	this->str = new char[len+1];
	strcpy(this->str,a.str);
}
int main(void)
{

	Str a("I'm a girl");
	cout << a.contents();
	a="I'm a boy\n";
	cout << a.contents();
	cout << a.compare("I'm a a") <<endl;
	return 0;
}
