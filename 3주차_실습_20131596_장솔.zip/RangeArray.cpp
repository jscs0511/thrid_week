#include <iostream>
#include "RangeArray.h"
#include "Array.h"

using namespace std;

RangeArray::RangeArray(int low,int high) :Array(high-low+1) {
	this->low = low;
	this->high = high;
}
RangeArray::~RangeArray() { ; }
int RangeArray::baseValue() {
	return low;
}
int RangeArray::endValue() {
	return high;
}
int & RangeArray::operator[] ( int i ) {
	static int tmp ;
	if ( i < low || i > high ) {
		cout << "Array bound error!" << endl;
		return tmp;
	}
	else
		return Array::data[i-low];
}
int RangeArray::operator[] (int i ) const {
	if ( i < low || i > high ) {
		cout << "Array bound error!" << endl;
		return 0;
	}
	else
		return Array::data[i-low];
}
